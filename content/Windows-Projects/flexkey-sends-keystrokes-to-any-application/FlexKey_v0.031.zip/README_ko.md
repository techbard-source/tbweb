﻿FlexKey 사용자 매뉴얼
====================

소개
----
FlexKey은 현재 활성화된 창에 키 입력을 보내는 간단한 도구입니다. 반복적인 타이핑 작업을 자동화하는 데 도움이 됩니다.

기본 사용법
----------
FK.exe "입력할 텍스트"

이 명령은 현재 활성화된 창에 텍스트를 보냅니다.

사용 예시
--------
1. 간단한 텍스트 입력:
   FK.exe "Hello World"

2. 키보드 단축키 사용:
   FK.exe "^c"        (Ctrl+C)
   FK.exe "^v"        (Ctrl+V)
   FK.exe "^s"        (Ctrl+S)

3. 키 조합:
   FK.exe "+{ENTER}"  (Shift+Enter)
   FK.exe "^+a"       (Ctrl+A)

4. 키 입력 사이 대기:
   FK.exe "A{WAIT 500}B"
   (A 입력, 0.5초 대기, 그 다음 B 입력)

5. 키 반복:
   FK.exe "{ENTER 5}" (Enter 5번 눌림)
   FK.exe "A{WAIT 100}" (A 키 잠깐 누르고 있음)

6. 현재 날짜 입력:
   FK.exe "{DATE}" --env

7. 현재 시간 입력:
   FK.exe "{TIME}" --env

8. 키보드 잠금 토글:
   FK.exe "{CAPSLOCK_ON}"   (Caps Lock 켜기)
   FK.exe "{NUMLOCK_OFF}"  (Num Lock 끄기)
   FK.exe "{SCROLLLOCK_ON}" (Scroll Lock 켜기)

옵션
-------
-p, --paste     클립보드 사용 (긴 텍스트에 더 빠름)
-r, --random    인간 같은 타이핑 속도
-e, --env      %USERNAME% 같은 변수와 {DATE} 확장
-t "Title"     입력 전 특정 창 선택
-h, --help     도움말 표시

변경자(Modifier)
---------
`+`  Shift (다음 키를 입력하는 동안 유지)
`^`  Ctrl  (다음 키를 입력하는 동안 유지)
`%`  Alt   (다음 키를 입력하는 동안 유지)

리터럴 +, ^, % 문자를 입력하려면:
   FK.exe "{+}"  (기호 + 입력)
   FK.exe "{^}"  (기호 ^ 입력)

팁
----
- 대시로 시작하는 텍스트 전송: FK.exe -t "창 제목" -- "-hello-"
- 공백이 포함된 텍스트는 따옴표로 감싸세요
- 인자 없이 FK.exe를 실행하면 도움말이 표시됩니다
- 종료 코드 22는 잘못된 인자를 의미합니다

문의처
-------
제작: JAEMUN, SHIN
연락처: techbard@naver.com

질문, 버그 리포트, 개선 제안은 위 이메일로 연락해 주세요.